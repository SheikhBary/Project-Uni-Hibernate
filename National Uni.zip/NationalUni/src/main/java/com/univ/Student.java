package com.univ;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Univ_Student")
public class Student implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="student_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	@Column(name="Stu_Phone")
	private int phone;
	
	@ManyToOne
	@JoinColumn(name = "FK_Dept_Id", referencedColumnName = "Dept_Id")
	private Department dept;

	@Column(name="Stu_Age")
	private int Age;

	@Column(name="Stu_Email")
	private String email;

	@Column(name="Stu_First_Name")
	private String firstName;

	@Column(name="Stu_Last_Name")
	private String lastName;

	@Column(name="Stu_Sex")
	private String sex;
	
	@Column(name="Stu_Total_Fee")
	private float totalFee;

	@Column(name="Stu_Total_Paid")
	private float paid;
	
	@Column(name="Stu_Total_Due")
	private float due;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public float getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(float totalFee) {
		this.totalFee = totalFee;
	}

	public float getPaid() {
		return paid;
	}

	public void setPaid(float paid) {
		this.paid = paid;
	}

	public float getDue() {
		return due;
	}

	public void setDue(float due) {
		this.due = due;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
